import base64
import io
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import xlsxwriter
from flask import Flask, render_template, request, jsonify

# Load the model
model = tf.keras.models.load_model("best_model.h5")

# Define the labels
labels = {0: "COVID19", 1: "NORMAL", 2: "PNEUMONIA", 3: "TUBERCULOSIS"}

# Initialize Flask application
app = Flask(__name__)

# Define the prediction function
def predict_image(img):
    # Preprocess the image
    img = tf.image.resize(img, (64, 64))
    img = np.array(img)
    img = img / 255.0
    img = np.expand_dims(img, axis=0)

    # Make a prediction
    prediction = model.predict(img)[0]
    label = np.argmax(prediction)

    # Return the label and probability scores
    return {labels[i]: float(prediction[i]) for i in range(len(labels))}, labels[label]

# Define the route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Define the route for image classification
@app.route('/classify', methods=['POST'])
# Define the route for image classification
@app.route('/classify', methods=['POST'])
# Define the route for image classification
@app.route('/classify', methods=['POST'])
def classify():
    # Get the uploaded image file
    file = request.files.get('image')

    if file is None:
        return jsonify({'error': 'No file uploaded'})

    # Read the image file
    img = tf.image.decode_image(file.read(), channels=3)

    # Perform prediction
    result, label = predict_image(img)

    # Create a horizontal bar graph of the prediction scores
    fig, ax = plt.subplots()
    colors = ['blue', 'green', 'red', 'purple']
    ax.barh(list(result.keys()), list(result.values()), color=colors)
    ax.set_xlim([0, 1])
    ax.set_xlabel('Probability (%)')
    ax.set_title('Image Classification Result')
    plt.tight_layout()

    # Convert the bar graph to a base64-encoded string
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    bar_graph_str = base64.b64encode(buf.read()).decode('utf-8')

    # Convert the Excel data to a base64-encoded string
    workbook = xlsxwriter.Workbook('classification_result.xlsx')
    worksheet = workbook.add_worksheet()
    row = 0
    col = 0
    worksheet.write(row, col, 'Class')
    worksheet.write(row, col+1, 'Probability')
    for key, value in result.items():
        row += 1
        worksheet.write(row, col, key)
        worksheet.write(row, col+1, value)
    workbook.close()
    excel_data_str = base64.b64encode(buf.getvalue()).decode('utf-8')

    # Return the prediction, bar graph, and Excel data as JSON response
    response = {'label': label, 'result': result, 'bar_graph': bar_graph_str, 'excel_data': excel_data_str}
    return jsonify(response)

   
# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)
